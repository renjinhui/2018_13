export const COLOR = 'CHANGE_COLOR'
export const SWIPER = 'GET_BANNER'
export const HOMELIST = 'HOMELIST'
export const HOMETITLE = 'HOMETITLE'