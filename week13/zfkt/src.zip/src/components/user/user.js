import React from 'react';
import ReactDOM from 'react-dom';
class App extends React.Component {
    constructor() {
        super();
        
    }
    render() {
        return <div className=''>
            用户中心
        </div>;
    }
}

export default App