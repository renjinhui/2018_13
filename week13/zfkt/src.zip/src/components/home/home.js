import React from 'react';
import ReactDOM from 'react-dom';
class App extends React.Component {
    constructor() {
        super();
        
    }
    render() {
        return <div className=''>
            首页
        </div>;
    }
}

export default App