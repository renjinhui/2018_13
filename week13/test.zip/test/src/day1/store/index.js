import {createStore,combineReducers} from '../../redux'

let store = createStore(colorReducer);

function colorReducer(state,action) {
    if(!state){
        return{
            color:'green'
        }
    }
    switch (action.type) {
        case 'CHANGE_COLOR':
            debugger
            return{
                ...state,
                color:action.color
            }
            break;
    
        default:
            return state
            break;
    }
}
// export default {store}
// // 这种使用方法要通过 解构的方式 获取store  是不支持的
export default store