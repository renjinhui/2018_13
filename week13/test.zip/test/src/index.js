import React from 'react';
import ReactDOM from 'react-dom'

import App from './day1/1_redux';

ReactDOM.render(<App />, document.getElementById('root'));
