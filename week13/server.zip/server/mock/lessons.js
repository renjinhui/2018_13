module.exports = [
  {
    id: 1,
    title: '1.React全栈架构',
    "video":"http://7xil5b.com1.z0.glb.clouddn.com/zhufengpeixun.mp4",
    poster:"http://www.zhufengpeixun.cn/react/img/react.jpg",
    url: 'http://www.zhufengpeixun.cn/themes/jianmo2/images/react.png',
    price: '¥100.00元',
    category:'react'
  },
  {
    id: 2,
    title: '2.React全栈架构',
    video:"http://7xil5b.com1.z0.glb.clouddn.com/zhufengpeixun.mp4",
    poster:"http://www.zhufengpeixun.cn/react/img/react.jpg",
    url: 'http://www.zhufengpeixun.cn/themes/jianmo2/images/react.png',
    price: '¥200.00元',
    category:'react'
  },
  {
    id: 3,
    title: '3.React全栈架构',
    video:"http://7xil5b.com1.z0.glb.clouddn.com/zhufengpeixun.mp4",
    poster:"http://www.zhufengpeixun.cn/react/img/react.jpg",
    url: 'http://www.zhufengpeixun.cn/themes/jianmo2/images/react.png',
    price: '¥300.00元',
    category:'react'
  },
  {
    id: 4,
    title: '4.React全栈架构',
    video:"http://7xil5b.com1.z0.glb.clouddn.com/zhufengpeixun.mp4",
    poster:"http://www.zhufengpeixun.cn/react/img/react.jpg",
    url: 'http://www.zhufengpeixun.cn/themes/jianmo2/images/react.png',
    price: '¥400.00元',
    category:'react'
  },
  {
    id: 5,
    title: '5.React全栈架构',
    video:"http://7xil5b.com1.z0.glb.clouddn.com/zhufengpeixun.mp4",
    poster:"http://www.zhufengpeixun.cn/react/img/react.jpg",
    url: 'http://www.zhufengpeixun.cn/themes/jianmo2/images/react.png',
    price: '¥500.00元',
    category:'react'
  },
  {
    id: 6,
    title: '6.Vue从入门到项目实战',
    video:"http://7xil5b.com1.z0.glb.clouddn.com/zhufengpeixun.mp4",
    poster:"http://www.zhufengpeixun.cn/vue/img/vue.png",
    url: 'http://www.zhufengpeixun.cn/themes/jianmo2/images/vue.png',
    price: '¥100.00元',
    category:'vue'
  },
  {
    id: 7,
    title: '7.Vue从入门到项目实战',
    video:"http://7xil5b.com1.z0.glb.clouddn.com/zhufengpeixun.mp4",
    poster:"http://www.zhufengpeixun.cn/vue/img/vue.png",
    url: 'http://www.zhufengpeixun.cn/themes/jianmo2/images/vue.png',
    price: '¥200.00元',
    category:'vue'
  },
  {
    id: 8,
    title: '8.Vue从入门到项目实战',
    video:"http://7xil5b.com1.z0.glb.clouddn.com/zhufengpeixun.mp4",
    poster:"http://www.zhufengpeixun.cn/vue/img/vue.png",
    url: 'http://www.zhufengpeixun.cn/themes/jianmo2/images/vue.png',
    price: '¥300.00元',
    category:'vue'
  },
  {
    id: 9,
    title: '9.Vue从入门到项目实战',
    video:"http://7xil5b.com1.z0.glb.clouddn.com/zhufengpeixun.mp4",
    poster:"http://www.zhufengpeixun.cn/vue/img/vue.png",
    url: 'http://www.zhufengpeixun.cn/themes/jianmo2/images/vue.png',
    price: '¥400.00元',
    category:'vue'
  },
  {
    id: 10,
    title: '10.Vue从入门到项目实战',
    video:"http://7xil5b.com1.z0.glb.clouddn.com/zhufengpeixun.mp4",
    poster:"http://www.zhufengpeixun.cn/vue/img/vue.png",
    url: 'http://www.zhufengpeixun.cn/themes/jianmo2/images/vue.png',
    price: '¥500.00元',
    category:'vue'
  },
  {
    id: 11,
    title: '11.React全栈架构',
    "video":"http://7xil5b.com1.z0.glb.clouddn.com/zhufengpeixun.mp4",
    poster:"http://www.zhufengpeixun.cn/react/img/react.jpg",
    url: 'http://www.zhufengpeixun.cn/themes/jianmo2/images/react.png',
    price: '¥600.00元',
    category:'react'
  },
  {
    id: 12,
    title: '12.React全栈架构',
    video:"http://7xil5b.com1.z0.glb.clouddn.com/zhufengpeixun.mp4",
    poster:"http://www.zhufengpeixun.cn/react/img/react.jpg",
    url: 'http://www.zhufengpeixun.cn/themes/jianmo2/images/react.png',
    price: '¥700.00元',
    category:'react'
  },
  {
    id: 13,
    title: '13.React全栈架构',
    video:"http://7xil5b.com1.z0.glb.clouddn.com/zhufengpeixun.mp4",
    poster:"http://www.zhufengpeixun.cn/react/img/react.jpg",
    url: 'http://www.zhufengpeixun.cn/themes/jianmo2/images/react.png',
    price: '¥800.00元',
    category:'react'
  },
  {
    id: 14,
    title: '14.React全栈架构',
    video:"http://7xil5b.com1.z0.glb.clouddn.com/zhufengpeixun.mp4",
    poster:"http://www.zhufengpeixun.cn/react/img/react.jpg",
    url: 'http://www.zhufengpeixun.cn/themes/jianmo2/images/react.png',
    price: '¥900.00元',
    category:'react'
  },
  {
    id: 15,
    title: '15.React全栈架构',
    video:"http://7xil5b.com1.z0.glb.clouddn.com/zhufengpeixun.mp4",
    poster:"http://www.zhufengpeixun.cn/react/img/react.jpg",
    url: 'http://www.zhufengpeixun.cn/themes/jianmo2/images/react.png',
    price: '¥1000.00元',
    category:'react'
  },
  {
    id: 16,
    title: '16.Vue从入门到项目实战',
    video:"http://7xil5b.com1.z0.glb.clouddn.com/zhufengpeixun.mp4",
    poster:"http://www.zhufengpeixun.cn/vue/img/vue.png",
    url: 'http://www.zhufengpeixun.cn/themes/jianmo2/images/vue.png',
    price: '¥600.00元',
    category:'vue'
  },
  {
    id: 17,
    title: '17.Vue从入门到项目实战',
    video:"http://7xil5b.com1.z0.glb.clouddn.com/zhufengpeixun.mp4",
    poster:"http://www.zhufengpeixun.cn/vue/img/vue.png",
    url: 'http://www.zhufengpeixun.cn/themes/jianmo2/images/vue.png',
    price: '¥700.00元',
    category:'vue'
  },
  {
    id: 18,
    title: '18.Vue从入门到项目实战',
    video:"http://7xil5b.com1.z0.glb.clouddn.com/zhufengpeixun.mp4",
    poster:"http://www.zhufengpeixun.cn/vue/img/vue.png",
    url: 'http://www.zhufengpeixun.cn/themes/jianmo2/images/vue.png',
    price: '¥800.00元',
    category:'vue'
  },
  {
    id: 19,
    title: '19.Vue从入门到项目实战',
    video:"http://7xil5b.com1.z0.glb.clouddn.com/zhufengpeixun.mp4",
    poster:"http://www.zhufengpeixun.cn/vue/img/vue.png",
    url: 'http://www.zhufengpeixun.cn/themes/jianmo2/images/vue.png',
    price: '¥900.00元',
    category:'vue'
  },
  {
    id: 20,
    title: '20.Vue从入门到项目实战',
    video:"http://7xil5b.com1.z0.glb.clouddn.com/zhufengpeixun.mp4",
    poster:"http://www.zhufengpeixun.cn/vue/img/vue.png",
    url: 'http://www.zhufengpeixun.cn/themes/jianmo2/images/vue.png',
    price: '¥1000.00元',
    category:'vue'
  }
]