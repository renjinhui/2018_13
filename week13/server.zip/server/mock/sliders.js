module.exports = [
  'http://www.zhufengpeixun.cn/themes/jianmo2/images/reactnative.png',
  'http://www.zhufengpeixun.cn/themes/jianmo2/images/react.png',
  'http://www.zhufengpeixun.cn/themes/jianmo2/images/vue.png',
  'http://www.zhufengpeixun.cn/themes/jianmo2/images/wechat.png',
  'http://www.zhufengpeixun.cn/themes/jianmo2/images/architect.jpg'
];