export const ADD = 'ADD_COUNT';
export const REMOVE = "REMOVE_COUNT";
export const COLOR = "CHANGE_COLOR";