module.exports = {
    // 不用eslint 限制你的代码
    lintOnSave:false
}