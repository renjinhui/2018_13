<template>
    <div class="swiper-container">
        <div class="swiper-wrapper">
            <div class="swiper-slide">Slide 1</div>
            <div class="swiper-slide">Slide 2</div>
            <div class="swiper-slide">Slide 3</div>
        </div>
        <div class="swiper-pagination"></div>
    </div>
</template>

<script>
// 引入 swiper 插件
import swiper from 'swiper'
export default {
    mounted(){
        // 初始化swiper时 我们需要让DOM渲染完成
        new swiper('.swiper-container',{

        })
    }
};
</script>

<style scoped>
</style>