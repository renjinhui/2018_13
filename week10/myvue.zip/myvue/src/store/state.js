const state = {
    count:0
}
export default state