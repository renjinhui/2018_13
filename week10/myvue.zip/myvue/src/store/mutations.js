export function addCount(state,option){
    state.count += option;
}
export function removeCount(state,option){
    state.count -= option;
}