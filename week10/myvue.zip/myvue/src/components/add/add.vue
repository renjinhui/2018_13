<template>
    <div class='add'>
        <my-title til='添加页'></my-title>
        添加页
    </div>
</template>

<script>
    import title from '@/common/title.vue'
    export default {
        components:{
            'my-title':title
        }
    }
</script>

<style scoped>

</style>