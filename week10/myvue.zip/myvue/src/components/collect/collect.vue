<template>
    <div class='collect'>
        <my-title til='收藏页'></my-title>
        收藏页
    </div>
</template>

<script>
    import title from '@/common/title.vue'
    export default {
        components:{
            'my-title':title
        }
    }
</script>

<style scoped>

</style>