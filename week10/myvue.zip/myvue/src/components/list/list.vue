<template>
    <div class='list'>
        <my-title til='列表页'></my-title>
        列表页
    </div>
</template>

<script>
    import title from '@/common/title.vue'
    export default {
        components:{
            'my-title':title
        }
    }
</script>

<style scoped>

</style>