<template>
    <div class='home'>
        <my-title til='首页'></my-title>
        <div class='swiper_box'>
            <swiper></swiper>
        </div>
        首页
    </div>
</template>

<script>
    import title from '@/common/title.vue'
    import swiper from '@/common/swiper.vue'
    export default {
        components:{
            'my-title':title,
            swiper
        }
    }
</script>

<style scoped lang='less'>
    .swiper_box{
        width: 100%;
        height: 4rem;
        background: #ccc;
        margin-top:1.5rem;
    }
</style>